# دوستان سورس رو بروزرسانی کنید فایل ارور به سورس اضافه شد

کسانی که اروری شبیه ارور زیر دریافت کردن
![https://raw.githubusercontent.com/robosaz/xtfa/%40janlou/up/IMG_20170626_095233.png](https://raw.githubusercontent.com/robosaz/xtfa/%40janlou/up/IMG_20170626_095233.png)

لطفا بصورت زیر عمل کنن تا مشکلشون برطرف بشه

اول سورس رو آپدیت کنین
```
cd xtfa install -y

```
بعد به شکل زیر رفع ارور کنن
```
./error.sh
A

```

اگر به این شکل انجام داده باشین ارور برطرف خواهد شد
![https://raw.githubusercontent.com/robosaz/xtfa/%40janlou/up/2017-06-26_10_36_05.gif](https://raw.githubusercontent.com/robosaz/xtfa/%40janlou/up/2017-06-26_10_36_05.gif)

