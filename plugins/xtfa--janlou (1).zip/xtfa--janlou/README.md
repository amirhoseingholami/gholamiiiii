#  <h1>  XtBot... XtFa

| XtBot by ShahinXT: |



| INSTALL BOT |
|:-----------------------|
- <p align="left">Clone Source:
```
# Install dependencies.

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev make unzip git redis-server g++ libjansson-dev libpython-dev expat libexpat1-dev
```

```
git clone https://github.com/robosaz/xtfa
cd xtfa
```
- <p align="left">install bot:
```sh
chmod 700 start.sh
./start.sh install
```
بعد دستور زیر رو اجرا کنید


| `screen ./steady.sh -t` |



# | T Bot |
# اجرا با شماره تلفن
```
/start.sh
```

# | Api Bot |
# اجرا با توکن ربات  


```
./start.sh api

```



| `screen ./steady.sh -t` |


# Auto Launch Confiure :

**  دستور اتولانچ ربات  **
```
tmux new-session -s script "bash steady.sh -t"
```

# کسانی که مشکل دارن بعد از نصب به آدرس زیر مراجعه کنین 

![بخش آموزشی نصب سورس و اعلام بروزرسانی ها](https://github.com/robosaz/xtfa/tree/@janlou/up)



## SuperGroup's languages ( !lang list):

<h2>|:----EN----|:-----FA-----|:------فا------|</h2>


## تنظیم ربات در ۳ نوع زبان

| <h2>/setlang `en`
| <h3>| در این نوع تنظیم دستورات ارسالی و پاسخ های دریافتی بصورت انگلیسی خواهد بود |

| <h2>/setlang `fa` 
| <h3>| در این نوع تنظیم دستورات ارسالی انگلیسی بوده و پاسخ های دریافتی بصورت فارسی خواهد بود |

| <h2>/setlang `فا` 
| <h3>| در این نوع تنظیم دستورات ارسالی و پاسخ های دریافتی بصورت فارسی خواهد بود |


 
# کانال پشتیبانی  

| Channel  @Xt_robo |
