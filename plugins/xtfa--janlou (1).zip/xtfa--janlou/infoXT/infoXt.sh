echo "    【Robo XtBot】   "
echo "By 👑 ShahinXt 👑
echo "Channel 👑 @xt_robo 👑
By 👑 ShahinXt 👑
echo "ID 👑 @SHAHIN_XTBOT 👑
